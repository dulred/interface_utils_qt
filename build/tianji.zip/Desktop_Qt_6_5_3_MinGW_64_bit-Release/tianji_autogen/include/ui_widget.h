/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 6.5.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *horizontalLayoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QDateTimeEdit *start_time;
    QDateTimeEdit *end_time;
    QPushButton *g_ts;
    QTextEdit *jsonText;
    QWidget *horizontalLayoutWidget_4;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *g_url;
    QTextEdit *url;
    QPushButton *send;
    QTextBrowser *response;
    QTextEdit *ip;
    QTextEdit *path;
    QTextEdit *secret;
    QTextEdit *appleid;
    QGroupBox *re_way;
    QRadioButton *get_button;
    QRadioButton *post_button;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName("Widget");
        Widget->resize(847, 724);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Widget->sizePolicy().hasHeightForWidth());
        Widget->setSizePolicy(sizePolicy);
        Widget->setMinimumSize(QSize(847, 716));
        Widget->setMaximumSize(QSize(847, 16777215));
        Widget->setAcceptDrops(false);
        horizontalLayoutWidget_3 = new QWidget(Widget);
        horizontalLayoutWidget_3->setObjectName("horizontalLayoutWidget_3");
        horizontalLayoutWidget_3->setGeometry(QRect(50, 150, 761, 51));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget_3);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        start_time = new QDateTimeEdit(horizontalLayoutWidget_3);
        start_time->setObjectName("start_time");

        horizontalLayout_3->addWidget(start_time);

        end_time = new QDateTimeEdit(horizontalLayoutWidget_3);
        end_time->setObjectName("end_time");
        end_time->setDateTime(QDateTime(QDate(2024, 7, 23), QTime(0, 0, 0)));

        horizontalLayout_3->addWidget(end_time);

        g_ts = new QPushButton(horizontalLayoutWidget_3);
        g_ts->setObjectName("g_ts");

        horizontalLayout_3->addWidget(g_ts);

        jsonText = new QTextEdit(Widget);
        jsonText->setObjectName("jsonText");
        jsonText->setGeometry(QRect(50, 210, 761, 101));
        horizontalLayoutWidget_4 = new QWidget(Widget);
        horizontalLayoutWidget_4->setObjectName("horizontalLayoutWidget_4");
        horizontalLayoutWidget_4->setGeometry(QRect(50, 320, 761, 41));
        horizontalLayout_4 = new QHBoxLayout(horizontalLayoutWidget_4);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        g_url = new QPushButton(horizontalLayoutWidget_4);
        g_url->setObjectName("g_url");

        horizontalLayout_4->addWidget(g_url);

        url = new QTextEdit(Widget);
        url->setObjectName("url");
        url->setGeometry(QRect(140, 370, 671, 41));
        send = new QPushButton(Widget);
        send->setObjectName("send");
        send->setGeometry(QRect(50, 440, 761, 31));
        response = new QTextBrowser(Widget);
        response->setObjectName("response");
        response->setGeometry(QRect(50, 490, 761, 192));
        ip = new QTextEdit(Widget);
        ip->setObjectName("ip");
        ip->setGeometry(QRect(50, 90, 381, 41));
        path = new QTextEdit(Widget);
        path->setObjectName("path");
        path->setGeometry(QRect(440, 90, 371, 41));
        secret = new QTextEdit(Widget);
        secret->setObjectName("secret");
        secret->setGeometry(QRect(440, 30, 371, 41));
        appleid = new QTextEdit(Widget);
        appleid->setObjectName("appleid");
        appleid->setGeometry(QRect(50, 30, 381, 41));
        re_way = new QGroupBox(Widget);
        re_way->setObjectName("re_way");
        re_way->setEnabled(true);
        re_way->setGeometry(QRect(60, 350, 71, 71));
        QFont font;
        font.setPointSize(9);
        font.setBold(false);
        font.setItalic(true);
        font.setUnderline(false);
        font.setStrikeOut(false);
        font.setKerning(true);
        re_way->setFont(font);
        re_way->setContextMenuPolicy(Qt::DefaultContextMenu);
        re_way->setStyleSheet(QString::fromUtf8(" border: none;\n"
"background: transparent;"));
        re_way->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        get_button = new QRadioButton(re_way);
        get_button->setObjectName("get_button");
        get_button->setGeometry(QRect(0, 20, 118, 23));
        post_button = new QRadioButton(re_way);
        post_button->setObjectName("post_button");
        post_button->setGeometry(QRect(0, 50, 118, 16));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        g_ts->setText(QCoreApplication::translate("Widget", "\347\224\237\346\210\220JSON\346\227\266\351\227\264\346\210\263", nullptr));
        jsonText->setPlaceholderText(QCoreApplication::translate("Widget", "json", nullptr));
        g_url->setText(QCoreApplication::translate("Widget", "\347\224\237\346\210\220url", nullptr));
        url->setPlaceholderText(QCoreApplication::translate("Widget", "\350\257\267\350\276\223\345\205\245\347\224\237\346\210\220\347\232\204url", nullptr));
        send->setText(QCoreApplication::translate("Widget", "send", nullptr));
        ip->setHtml(QCoreApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        ip->setPlaceholderText(QCoreApplication::translate("Widget", "ip", nullptr));
        path->setHtml(QCoreApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        path->setPlaceholderText(QCoreApplication::translate("Widget", "path", nullptr));
        secret->setHtml(QCoreApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        secret->setPlaceholderText(QCoreApplication::translate("Widget", "secret", nullptr));
        appleid->setHtml(QCoreApplication::translate("Widget", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        appleid->setPlaceholderText(QCoreApplication::translate("Widget", "appleid", nullptr));
#if QT_CONFIG(tooltip)
        re_way->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        re_way->setTitle(QString());
        get_button->setText(QCoreApplication::translate("Widget", "GET", nullptr));
        post_button->setText(QCoreApplication::translate("Widget", "POST", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
