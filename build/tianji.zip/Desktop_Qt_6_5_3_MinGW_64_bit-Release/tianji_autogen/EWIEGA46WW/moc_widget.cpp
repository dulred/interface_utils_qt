/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../widget.h"
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSWidgetENDCLASS = QtMocHelpers::stringData(
    "Widget",
    "onAppleIdChanged",
    "",
    "onSecretChanged",
    "onIpChanged",
    "onPathChanged",
    "onStartTimeChanged",
    "onEndTimeChanged",
    "onJsonTextChanged",
    "onUrlChanged",
    "showSelectedRadioButton",
    "generateJson",
    "generateUrl",
    "send",
    "onGetRequest",
    "onPostRequest",
    "onHttpRequest",
    "onNetworkReply",
    "QNetworkReply*",
    "reply",
    "onPostButtonClicked",
    "onGetButtonClicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSWidgetENDCLASS_t {
    uint offsetsAndSizes[44];
    char stringdata0[7];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[16];
    char stringdata4[12];
    char stringdata5[14];
    char stringdata6[19];
    char stringdata7[17];
    char stringdata8[18];
    char stringdata9[13];
    char stringdata10[24];
    char stringdata11[13];
    char stringdata12[12];
    char stringdata13[5];
    char stringdata14[13];
    char stringdata15[14];
    char stringdata16[14];
    char stringdata17[15];
    char stringdata18[15];
    char stringdata19[6];
    char stringdata20[20];
    char stringdata21[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSWidgetENDCLASS_t qt_meta_stringdata_CLASSWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 6),  // "Widget"
        QT_MOC_LITERAL(7, 16),  // "onAppleIdChanged"
        QT_MOC_LITERAL(24, 0),  // ""
        QT_MOC_LITERAL(25, 15),  // "onSecretChanged"
        QT_MOC_LITERAL(41, 11),  // "onIpChanged"
        QT_MOC_LITERAL(53, 13),  // "onPathChanged"
        QT_MOC_LITERAL(67, 18),  // "onStartTimeChanged"
        QT_MOC_LITERAL(86, 16),  // "onEndTimeChanged"
        QT_MOC_LITERAL(103, 17),  // "onJsonTextChanged"
        QT_MOC_LITERAL(121, 12),  // "onUrlChanged"
        QT_MOC_LITERAL(134, 23),  // "showSelectedRadioButton"
        QT_MOC_LITERAL(158, 12),  // "generateJson"
        QT_MOC_LITERAL(171, 11),  // "generateUrl"
        QT_MOC_LITERAL(183, 4),  // "send"
        QT_MOC_LITERAL(188, 12),  // "onGetRequest"
        QT_MOC_LITERAL(201, 13),  // "onPostRequest"
        QT_MOC_LITERAL(215, 13),  // "onHttpRequest"
        QT_MOC_LITERAL(229, 14),  // "onNetworkReply"
        QT_MOC_LITERAL(244, 14),  // "QNetworkReply*"
        QT_MOC_LITERAL(259, 5),  // "reply"
        QT_MOC_LITERAL(265, 19),  // "onPostButtonClicked"
        QT_MOC_LITERAL(285, 18)   // "onGetButtonClicked"
    },
    "Widget",
    "onAppleIdChanged",
    "",
    "onSecretChanged",
    "onIpChanged",
    "onPathChanged",
    "onStartTimeChanged",
    "onEndTimeChanged",
    "onJsonTextChanged",
    "onUrlChanged",
    "showSelectedRadioButton",
    "generateJson",
    "generateUrl",
    "send",
    "onGetRequest",
    "onPostRequest",
    "onHttpRequest",
    "onNetworkReply",
    "QNetworkReply*",
    "reply",
    "onPostButtonClicked",
    "onGetButtonClicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  122,    2, 0x08,    1 /* Private */,
       3,    0,  123,    2, 0x08,    2 /* Private */,
       4,    0,  124,    2, 0x08,    3 /* Private */,
       5,    0,  125,    2, 0x08,    4 /* Private */,
       6,    0,  126,    2, 0x08,    5 /* Private */,
       7,    0,  127,    2, 0x08,    6 /* Private */,
       8,    0,  128,    2, 0x08,    7 /* Private */,
       9,    0,  129,    2, 0x08,    8 /* Private */,
      10,    0,  130,    2, 0x08,    9 /* Private */,
      11,    0,  131,    2, 0x08,   10 /* Private */,
      12,    0,  132,    2, 0x08,   11 /* Private */,
      13,    0,  133,    2, 0x08,   12 /* Private */,
      14,    0,  134,    2, 0x08,   13 /* Private */,
      15,    0,  135,    2, 0x08,   14 /* Private */,
      16,    0,  136,    2, 0x08,   15 /* Private */,
      17,    1,  137,    2, 0x08,   16 /* Private */,
      20,    0,  140,    2, 0x08,   18 /* Private */,
      21,    0,  141,    2, 0x08,   19 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Widget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Widget, std::true_type>,
        // method 'onAppleIdChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onSecretChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onIpChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onPathChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onStartTimeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onEndTimeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onJsonTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onUrlChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showSelectedRadioButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'generateJson'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'generateUrl'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'send'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onGetRequest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onPostRequest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onHttpRequest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onNetworkReply'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QNetworkReply *, std::false_type>,
        // method 'onPostButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onGetButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Widget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onAppleIdChanged(); break;
        case 1: _t->onSecretChanged(); break;
        case 2: _t->onIpChanged(); break;
        case 3: _t->onPathChanged(); break;
        case 4: _t->onStartTimeChanged(); break;
        case 5: _t->onEndTimeChanged(); break;
        case 6: _t->onJsonTextChanged(); break;
        case 7: _t->onUrlChanged(); break;
        case 8: _t->showSelectedRadioButton(); break;
        case 9: _t->generateJson(); break;
        case 10: _t->generateUrl(); break;
        case 11: _t->send(); break;
        case 12: _t->onGetRequest(); break;
        case 13: _t->onPostRequest(); break;
        case 14: _t->onHttpRequest(); break;
        case 15: _t->onNetworkReply((*reinterpret_cast< std::add_pointer_t<QNetworkReply*>>(_a[1]))); break;
        case 16: _t->onPostButtonClicked(); break;
        case 17: _t->onGetButtonClicked(); break;
        default: ;
        }
    }
}

const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
